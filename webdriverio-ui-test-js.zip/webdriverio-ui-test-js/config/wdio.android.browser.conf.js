const { config } = require('./wdio.shared.conf');

// ============
// Specs
// ============
config.specs = [
    './src/features/mobile/**/*.feature'
];

// ================
// Cucumber Options
// ================
config.cucumberOpts = {
    require: ['./src/step-definitions/*'],
    backtrace: false,
    requireModule: [],
    dryRun: false,
    failFast: false,
    format: ['pretty'],
    snippets: true,
    source: true,
    profile: [],
    strict: false,
    tagExpression: '@mobile',
    timeout: 120000,
    ignoreUndefinedDefinitions: false
},

    // ====================
    // Appium Configuration
    // ====================
    config.port = 4723,
    config.path = "/wd/hub",
    config.services = [
        [
            'appium',
            {
                args: {
                },
                command: 'appium',
            },
        ],
    ],

    // ============
    // Capabilities
    // ============
    config.capabilities = [
        {
            platformName: 'Android',
            browserName: 'chrome',
            maxInstances: 1,
            'appium:deviceName': 'Pixel_XL_API_30',
            'appium:platformVersion': '11',
            'appium:orientation': 'PORTRAIT',
            'appium:automationName': 'UiAutomator2',
            'appium:newCommandTimeout': 240,
            'goog:chromeOptions': {
                w3c: true,
                args: ['--no-first-run'],
            },

            'cjson:metadata': {
                device: 'Google Pixel XL',
                platform: {
                    name: 'Android',
                    version: '11.0'
                }
            }, // metadata
        }, // android
    ];

exports.config = config;
