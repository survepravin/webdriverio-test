const actionHelper = require('../helpers/ActionHelper');
const assert = require('assert');

class ProductCategoryPage {

    getObjectLocator() {
        return require('../locators/ProductCategoryPageLocators');
    }

    navigateToCategory() {
        actionHelper.pause(3);
        let navigationMenu = "//div[contains(@class,'navigation__menu')]";
        let clickMenuIcon = "//label[@for='checkscroll']";
        actionHelper.scrollUp();
        let displayText = actionHelper.getCSSProperty(navigationMenu, "display");
        if (displayText == "block") actionHelper.clickJs(clickMenuIcon);
        actionHelper.pause(1);
        let elementCategories = actionHelper.getElements(this.getObjectLocator().listCategories);
        actionHelper.click(elementCategories[0]);
        actionHelper.pause(3);
        actionHelper.waitTillPageLoad();
    }

    navigateToCategoryMobile() {
        actionHelper.pause(3);
        let navigationMenu = "//button[contains(@class,'mobile__nav__row--btn-menu')]";
        let homepageButton = "//button[contains(@class,'mobile__nav__row--btn-search')]//a";
        actionHelper.click(homepageButton);
        actionHelper.waitTillPageLoad();
        actionHelper.click(navigationMenu);
        actionHelper.pause(1);
        let elementCategories = actionHelper.getElements(this.getObjectLocator().listCategories);
        actionHelper.clickJs(elementCategories[0]);
        actionHelper.pause(3);
        actionHelper.waitTillPageLoad();
    }

    navigateToSubCategory() {
        let elementSubCategories = actionHelper.getElements(this.getObjectLocator().listSubCategories);
        actionHelper.click(elementSubCategories[0]);
        actionHelper.waitTillPageLoad();
    }

    getGridIcons() {
        return actionHelper.getElements(this.getObjectLocator().elementGridIcons);
    }

    getListIcons() {
        return actionHelper.getElements(this.getObjectLocator().elementListIcons);
    }

    getSortDropdowns() {
        return actionHelper.getElements(this.getObjectLocator().elementSortDropDowns);
    }

    getPageTitle() {
        return this.getObjectLocator().title;
    }

    verifyShadowOnThumbnail() {
        actionHelper.waitForElement(this.getObjectLocator().listOfThumbnails);
        let eleProductImgs = actionHelper.getElements(this.getObjectLocator().listOfThumbnails);
        let shadow = eleProductImgs[0].getCSSProperty("box-shadow").value;
        assert.notEqual(shadow, 'none', "No shadow by default for 1st thumbnail");
        for (var i = 1; i < eleProductImgs.length; i++) {
            let element = eleProductImgs[i];
            actionHelper.click(element);
            actionHelper.pause(1);
            let thumbnail = element.getCSSProperty("box-shadow").value;
            assert.equal(thumbnail, shadow, "Thumbnail shadow not available");
        }
    }

    isPreviousButtonDisplayed() {
        return actionHelper.isDisplayedInViewport(this.getObjectLocator().btnPrev);
    }

    isNextButtonDisplayed() {
        return actionHelper.isDisplayedInViewport(this.getObjectLocator().btnNext);
    }

    verifyCheckboxPixels(expectedPixel) {
        let eleChecboxes = actionHelper.getElements(this.getObjectLocator().chkCheckboxes);
        eleChecboxes.forEach(element => {
            let actualPixel = actionHelper.getCSSProperty(element, "border-radius");
            assert.equal(actualPixel, expectedPixel, "pixel size doesn't match : expected " + expectedPixel + " pixel , but found " + actualPixel);
        });
    }

}

module.exports = new ProductCategoryPage();