const actionHelper = require('../helpers/ActionHelper');
const reportLog = require('../helpers/ReporterLog');
const config = require('../../config/wdio.shared.conf').config;
const assert = require('assert');

class WelcomePage {

    getObjectLocator() {
        return require('../locators/WelcomePageLocators');
    }

    footer() {
        return this.getObjectLocator().lblFooterText;
    }

    clickOnLogin() {
        actionHelper.clickJs(this.getObjectLocator().lnkLogin);
        actionHelper.waitTillPageLoad();
    }

    getPageTitle() {
        return this.getObjectLocator().title;
    }

    compareDropDownHeightAttribute() {
        let eleDropdowns = actionHelper.getElements(this.getObjectLocator().drpProductUnits);
        for (var i = 0; i < eleDropdowns.length; i++) {
            let element = eleDropdowns[i];
            element.scrollIntoView();
            element.waitForClickable({ timeout: 10000 });
            browser.execute("arguments[0].click();", element);
            let ul = element.$("ul");
            let lis = ul.$$("li");
            if (lis.length > 1) {
                for (var j = 0; j < lis.length; j++) {
                    let height = lis[j].getCSSProperty("min-height").value;
                    assert.equal(height, "40px");
                }
                break;
            } // end if
        } //end outer for
    }

    openProduct() {
        var elementProduct = actionHelper.getElements(this.getObjectLocator().listProduct)[0];
        actionHelper.scrollIntoView(elementProduct);
        actionHelper.pause(1);
        actionHelper.clickJs(elementProduct);
        actionHelper.waitTillPageLoad();
        browser.pause(5000);
    }

    verifyLoginTextCase() {
        let actualCase = actionHelper.getCSSProperty(this.getObjectLocator().lnkLogin, "text-transform");
        if (actualCase == "uppercase") {
            return true;
        }
        return false;
    }

    clickOnMyAccountLink() {
        actionHelper.pause(2);
        actionHelper.clickJs(this.getObjectLocator().lnkMyAccount);
        actionHelper.pause(2);
    }

    getAllMyAccountLinks() {
        let eleMyAccountLinkList = actionHelper.getElements(this.getObjectLocator().listMyAccountLinks);
        let obj = { "names": "", "links": "" };
        let actualNames = [];
        let actualLinks = [];
        for (let j = 0; j < eleMyAccountLinkList.length; j++) {
            let element = eleMyAccountLinkList[j];
            actualNames[j] = element.getText().trim();
            actualLinks[j] = element.getAttribute("href").replace(config.baseUrl, "").trim();
        }
        obj.names = actualNames;
        obj.links = actualLinks;
        return obj;
    }

    navigateTo() {
        actionHelper.clickJs(this.getObjectLocator().imgWelcomePage);
        actionHelper.waitTillPageLoad();
    }

    navigateToCart() {
        actionHelper.clickJs(this.getObjectLocator().lnkAddToCart);
        actionHelper.waitTillPageLoad();
    }

    verifyProductIdVisibility() {
        var listOfProductIds = actionHelper.getElements(this.getObjectLocator().lblProductIds);
        actionHelper.waitForElement(listOfProductIds[0]);
        for (let j = 0; j < listOfProductIds.length; j++) {
            let element = listOfProductIds[j];
            actionHelper.scrollIntoView(element);
            actionHelper.pause(1);
            let id = element.getText();
            if (!(id.length > 0)) {
                actionHelper.zoom("OUT");
                reportLog.addImage(actionHelper.takeScreenshot());
                actionHelper.zoom("");
                return false;
            }
            if (j == 10) return true;
        }
        return true;
    }

    verifyPriceIsBold() {
        let regexText = /R\$[0-9., ]*/g;
        let eleDropdowns = actionHelper.getElements(this.getObjectLocator().drpProductUnits);
        let element = eleDropdowns[0];
        actionHelper.scrollIntoView(element);
        actionHelper.waitForClickable(element);
        actionHelper.clickJs(element);
        let ul = element.$("ul");
        let lis = ul.$$("li");
        lis.forEach(li => {
            let bTag = li.$("b").getText();
            let text = bTag.match(regexText);
            assert.ok(text.length > 0, "text not bold or missing");
        });
        lis[lis.length - 1].click();
        let bTag = element.$("ul").$("b").getText();
        let text = bTag.match(regexText);
        assert.ok(text.length > 0, "After selecting value text is not bold or missing");
    }

    logout() {
        this.clickOnMyAccountLink();
        actionHelper.click(this.getObjectLocator().lnkLogout);
        actionHelper.waitTillPageLoad();
    }
}

module.exports = new WelcomePage();