const actionHelper = require('../helpers/ActionHelper');

class LoginPage {

    getObjectLocator() {
        return require('../locators/LoginPageLocators');
    }

    doLogin(username, password) {
        actionHelper.sendText(this.getObjectLocator().txtUsername, username);
        actionHelper.sendText(this.getObjectLocator().txtPassword, password);
        actionHelper.clickJs(this.getObjectLocator().btnSubmit);
        actionHelper.waitTillPageLoad();
    }

    getPageTitle() {
        return this.getObjectLocator().title;
    }

    getForgotPasswordText() {
        actionHelper.click(this.getObjectLocator().lnkForgotPassword);
        actionHelper.waitForElement(this.getObjectLocator().txtForgotPasswordDescription);
        return actionHelper.getText(this.getObjectLocator().txtForgotPasswordDescription);
    }
}

module.exports = new LoginPage();