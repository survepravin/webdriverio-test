const { Given, When, Then } = require('cucumber');
const assert = require('assert');
require('dotenv').config();
var welcomePage = require('../pages/WelcomePage');
var loginPage = require('../pages/LoginPage');
var productCategoryPage = require('../pages/ProductCategoryPage');
const actionHelper = require('../helpers/ActionHelper');
const reportLog = require('../helpers/ReporterLog');

When('User logins with username and password', () => {
    // click on login button
    welcomePage.clickOnLogin();
    actionHelper.pause(3);
    expect(browser).toHaveTitle(loginPage.getPageTitle());

    // enter username and password
    var users = ["01.026.008/0001-90", "01.023.826/0001-39", "01.027.335/0003-28"];
    const random = Math.floor(Math.random() * users.length);
    let user = users[random];
    // let user  = process.env.USERNAME;

    reportLog.addPlainText("User : " + user);
    loginPage.doLogin(user, process.env.PASSWORD);
    actionHelper.pause(3);
});

Then('User should land on welcome page', () => {
    expect(browser).toHaveTitle(welcomePage.getPageTitle());
});

When('User navigates to product category page', () => {
    productCategoryPage.navigateToCategory();
    let actualTitle = actionHelper.getTitle();
    let expectedTitle = productCategoryPage.getPageTitle();
    assert.ok(actualTitle.includes(expectedTitle), "Title didn't match, found : " + actualTitle);
});

When('MobileUser navigates to product category page', () => {
    productCategoryPage.navigateToCategoryMobile();
    let actualTitle = actionHelper.getTitle();
    let expectedTitle = productCategoryPage.getPageTitle();
    assert.ok(actualTitle.includes(expectedTitle), "Title didn't match, found : " + actualTitle);
});

Then('User should see single grid icon, list icon and sorting dropdown', () => {
    expect(productCategoryPage.getGridIcons()).toBeElementsArrayOfSize(1);
    expect(productCategoryPage.getListIcons()).toBeElementsArrayOfSize(1);
    expect(productCategoryPage.getSortDropdowns()).toBeElementsArrayOfSize(1);
});


Then('Verify footer institutional text is {string}', (text) => {
    actionHelper.scrollIntoView(welcomePage.footer());
    if ("BLANK" == text.toUpperCase()) {
        expect(actionHelper.getElement(welcomePage.footer())).toHaveText('');
    }
});

Then('Verify dropdown options has same height attribute', () => {
    welcomePage.compareDropDownHeightAttribute();
});

Then('Verify shadow on PDP thumbnail', () => {
    actionHelper.waitTillPageLoad();
    welcomePage.openProduct();
    productCategoryPage.verifyShadowOnThumbnail();
});

Then('Verify arrow buttons on PDP thumbnail', () => {
    assert.ok(productCategoryPage.isPreviousButtonDisplayed(), "Previous button is not displayed");
    assert.ok(productCategoryPage.isNextButtonDisplayed(), "Next button is not displayed");
});

Then('Verify login text is uppercase', () => {
    assert.ok(welcomePage.verifyLoginTextCase(), "Login text is not uppercase ");
});

Then('Verify My Account options', (table) => {
    let expectedNames = [];
    let expectedLinks = [];
    for (let i = 0; i < table.hashes().length; i++) {
        expectedNames[i] = table.hashes()[i].LinkName;
        expectedLinks[i] = table.hashes()[i].LinkUrl;
    }

    welcomePage.clickOnMyAccountLink();
    var obj = welcomePage.getAllMyAccountLinks();

    assert.deepEqual(obj.names, expectedNames, "My Account list name doesn't match : ", obj.names);
    assert.deepEqual(obj.links, expectedLinks, "My Account urls doesn't match : " + obj.links);
});

Then('Verify checkbox has round borders of {string}', (expectedPixel) => {
    productCategoryPage.verifyCheckboxPixels(expectedPixel);
});

Then('Verify unit dropdown has round edges at the bottom of {string}', (expectedPixelSize) => {
    let eleDropdowns = $$("//div[contains(@class,'nice-select')]");
    for (var i = 0; i < eleDropdowns.length; i++) {
        let element = eleDropdowns[i];
        element.scrollIntoView();
        element.waitForClickable({ timeout: 10000 });
        browser.execute("arguments[0].click();", element);
        let ul = element.$("ul");
        let lis = ul.$$("li");
        let leftRadiusPx = "";
        let rightRadiusPx = "";
        if (lis.length == 1) {
            leftRadiusPx = lis[0].getCSSProperty("border-bottom-left-radius").value;
            rightRadiusPx = lis[0].getCSSProperty("border-bottom-right-radius").value;
        } else {
            leftRadiusPx = lis[lis.length - 1].getCSSProperty("border-bottom-left-radius").value;
            rightRadiusPx = lis[lis.length - 1].getCSSProperty("border-bottom-right-radius").value;
        }
        assert.equal(leftRadiusPx, rightRadiusPx, "left and right border-bottom are not equal pixel : " + leftRadiusPx);
        assert.equal(leftRadiusPx, expectedPixelSize, "left and right border-bottom doesn't match : " + leftRadiusPx);
        break;
    };
});

When('User selects a product from {string} and adds to cart', (productCategory) => {
    let eleItems = "//div[@class='carousel__component--headline' and contains(.,'" + productCategory + "')]//parent::div//div[@class='owl-wrapper-outer']//div[@class='owl-item']//div[@class='carousel__item']";
    let eleBuyButton = "//div[contains(@class,'carousel__item--buy')]//button[not(contains(@class,'hidden'))]";
    let eleItemDesc = "//div[@class='carousel__item--description']";

    actionHelper.pause(3);
    var eleAvailableItemButton = $$(eleItems + eleBuyButton);
    var eleAvailableItemDesc = $$(eleItems + eleItemDesc);

    eleAvailableItemButton[0].scrollIntoView();

    for (let i = 0; i < eleAvailableItemButton.length; i++) {
        var button = eleAvailableItemButton[i];
        var buttonText = button.getText().trim().toUpperCase();
        if ("COMPRAR" == buttonText) {
            let itemDesc = eleAvailableItemDesc[i].getText();
            console.log(itemDesc);
            browser.execute("arguments[0].click();", button);
            actionHelper.waitTillPageLoad();
            break;
        }

    }
    browser.pause(3000);
});

Then('Navigate to cart', () => {
    welcomePage.navigateToCart();
});

Then('Navigate to login page', () => {
    welcomePage.clickOnLogin();
});

Then('Navigate to welcome page', () => {
    welcomePage.navigateTo();
});

Then('Verify the link {string} and {string} is present', (link1, link2) => {
    let eleCartLinks = $$("//div[contains(@class,'cart-header')]//a");
    var actualTexts = [];
    let i = 0;
    eleCartLinks.forEach(element => {
        let text = element.getText().trim();
        actualTexts[i] = text.toUpperCase();
        i++;
        assert.equal(element.getCSSProperty("text-transform").value, "uppercase", "Link text is not in uppercase : " + text);
    });

    assert.ok(actualTexts.includes(link1.toUpperCase()), link1 + " not found on Cart page");
    assert.ok(actualTexts.includes(link2.toUpperCase()), link2 + " not found on Cart page");
});

Then("Verify text forgot password text {string}", (expectedText) => {
    let actualText = loginPage.getForgotPasswordText();
    assert.equal(expectedText, actualText, "Forgot password text doesn't match : " + actualText);
});

Then("Verify product id on homepage", () => {
    assert.ok(welcomePage.verifyProductIdVisibility(), "Product Id not visibile ");
});

Then("Verify product price is bold", () => {
    welcomePage.verifyPriceIsBold();
});

var productDesc = [];
When("User adds {int} product from welcome page", (noOfProducts) => {
    let eleItems = "//div[@class='carousel__component--headline' and contains(.,'')]//parent::div//div[@class='owl-wrapper-outer']//div[@class='owl-item']//div[@class='carousel__item']";
    let eleBuyButton = "//div[contains(@class,'carousel__item--buy')]//button[not(contains(@class,'hidden'))]";
    let eleItemDesc = "//div[@class='carousel__item--description' or @class='carousel__item--name']";

    actionHelper.pause(3);
    actionHelper.scrollIntoView("//div[contains(@class,'carouselbrandpartners')]");
    let counter = 0;
    while (counter < noOfProducts) {
        var eleAvailableItemButton = $$(eleItems + eleBuyButton);
        var eleAvailableItemDesc = $$(eleItems + eleItemDesc);
        const random = Math.floor(Math.random() * eleAvailableItemButton.length);
        var button = eleAvailableItemButton[random];
        var buttonText = button.getText().trim().toUpperCase();
        if ("COMPRAR" == buttonText) {
            // eleAvailableItemButton[random].scrollIntoView();
            // let itemDesc = eleAvailableItemDesc[random].getText();
            let itemDesc = actionHelper.getTextJs(eleAvailableItemDesc[random]);
            productDesc[counter] = itemDesc.trim();
            actionHelper.clickJs(button);
            actionHelper.pause(1);
            try {
                $("//div[@id='cboxWrapper']//button[@id='cboxClose']").click();
                actionHelper.pause(1);
            } catch (exception) { }
            actionHelper.waitTillPageLoad();
            counter++;
        } // end if
    } // end while
    console.log(productDesc);
});

Then("User adds {int} product from category page", (noOfProducts) => {
    let eleItems = "//div[contains(@class,'product__listing')]//li[@class='product__list--item']";
    let eleBuyButton = "//div[contains(@class,'addtocart')]//button[contains(@id,'addtocart')]";
    let eleItemDesc = "//a[@class='product__list--name']";

    actionHelper.pause(3);
    let counter = 0;
    while (counter < noOfProducts) {
        var eleAvailableItemButton = $$(eleItems + eleBuyButton);
        var eleAvailableItemDesc = $$(eleItems + eleItemDesc);
        const random = Math.floor(Math.random() * eleAvailableItemButton.length);
        var button = eleAvailableItemButton[random];
        var buttonText = button.getText().trim().toUpperCase();
        if ("COMPRAR" == buttonText) {
            actionHelper.scrollIntoView(eleAvailableItemDesc[random]);
            let itemDesc = actionHelper.getTextJs(eleAvailableItemDesc[random]);
            productDesc[counter] = itemDesc.trim();
            actionHelper.clickJs(button);
            actionHelper.pause(1);
            try {
                $("//div[@id='cboxWrapper']//button[@id='cboxClose']").click();
                actionHelper.pause(1);
            } catch (exception) { }
            actionHelper.waitTillPageLoad();
            counter++;
        } // end if
    } // end while
    console.log(productDesc);
});

Then("Verify the products in the cart", () => {
    let eleCartItemName = "//table//li[contains(@class,'item__list--item')]//div[@class='item__info']//span[@class='item__name' and contains(.,'%s')]";
    let eleCartheadline = "//h1[@class='cart-headline']";
    let notFoundProducts = [];
    let i = 0;
    actionHelper.scrollIntoView(eleCartheadline);
    productDesc.forEach(productDesc => {
        eleCartItemName = eleCartItemName.replace("%s", productDesc.trim());
        let value = actionHelper.getElements(eleCartItemName);
        if (value.length == 0) notFoundProducts[i++] = productDesc;
    });
    assert.ok(notFoundProducts.length == 0, "Products not available in the cart : " + notFoundProducts);
});

Then("Finalize the purchase", () => {
    let eleFinalizeButton = "//div[@class='cart__actions']//button";
    actionHelper.waitForElement(eleFinalizeButton);
    actionHelper.scrollIntoView(eleFinalizeButton);
    let checkClass = actionHelper.getAttributeValue(eleFinalizeButton, "class");
    if (checkClass.includes("disabled")) assert.ok(false, "Finalize button is disable..");
    actionHelper.clickJs(eleFinalizeButton);
    actionHelper.waitTillPageLoad();
});

Then("Checkout", () => {
    let chkPaymentTerm = "//div[contains(@class,'checkoutSuPage__addresspayment--payment-term')]//span[@id='paymentTerm']";
    let paymentTermDesc = "//span[@class='checkoutSuPage__addresspayment--payment-term-label']";
    actionHelper.waitForElement(chkPaymentTerm);
    var listPaymentTerms = actionHelper.getElements(chkPaymentTerm);
    var listPaymentTermDesc = actionHelper.getElements(paymentTermDesc);
    const random = Math.floor(Math.random() * listPaymentTerms.length);

    listPaymentTerms[random].click();
    actionHelper.pause(5);
    actionHelper.waitTillPageLoad();
    actionHelper.pause(5);

    let isChecked = actionHelper.getAttributeValue(listPaymentTerms[random], "class");
    assert.ok(isChecked.includes("_checked"), "Payment term check box not selected");

    let payTermText = listPaymentTermDesc[random].getText();
    reportLog.addPlainText("Payment Term : " + payTermText);
    var taxValue = payTermText.match(/[0-9.]*%/g) + "";
    taxValue = taxValue.replace("%", "");

    let eleSubTotal = "//div[@class='subtotal']//div[contains(@class,'totalsubtotal')]";
    let eleTax = "//div[@class='tax']//div[contains(@class,'text-right')]";
    let eleTotal = "//div[@class='totals']//div[contains(@class,'text-right')]";

    actionHelper.scrollIntoView(eleSubTotal);
    let subtotal = removeCurencyString(actionHelper.getText(eleSubTotal));
    let tax;
    try {
        tax = removeCurencyString(actionHelper.getText(eleTax));
    } catch (exception) { }
    let total = removeCurencyString(actionHelper.getText(eleTotal));

    let value = calcTax(taxValue, subtotal);
    reportLog.addPlainText("Expected tax : " + value);
    reportLog.addPlainText("Actual tax : " + tax);
    if (tax != undefined) assert.equal(tax, value, "Tax miscalculated");

    let expectedTotal = value + parseFloat(subtotal);
    expectedTotal = expectedTotal.toFixed(2);
    reportLog.addPlainText("Expected total : " + expectedTotal);
    reportLog.addPlainText("Actual total : " + total);
    assert.equal(total, expectedTotal, "Total doesn't match with payment term")

    let btnPlaceOrder = "//button[@id='placeOrder']";
    actionHelper.scrollIntoView(btnPlaceOrder);
    reportLog.addImage(actionHelper.takeScreenshot());
    actionHelper.clickJs(btnPlaceOrder);
    actionHelper.pause(3);
    actionHelper.waitTillPageLoad();

    let orderId = "//*[@class='checkout__success--order']";
    let orderDate = "//*[@class='checkout__success--date']";
    actionHelper.waitForElement(orderId);
    let id = actionHelper.getText(orderId);
    let date = actionHelper.getText(orderDate);
    reportLog.addPlainText(id);
    reportLog.addPlainText(date);
    reportLog.addImage(actionHelper.takeScreenshot());

    let eleTotalDetails = "//div[@class='account-orderdetail']//div[contains(@class,'order__totals--details') and contains(.,'%s')]//following-sibling::div[contains(@class,'order__totals--price')]"

    let eleSubTotal_CO = removeCurencyString(actionHelper.getText(eleTotalDetails.replace("%s", "Subtotal")));
    let eleTax_CO;
    try {
        eleTax_CO = removeCurencyString(actionHelper.getText(eleTotalDetails.replace("%s", "Acréscimo")));
    } catch (exception) { }
    let eleTotal_CO = removeCurencyString(actionHelper.getText(eleTotalDetails.replace("%s", "Total")));
    let elePaymentTerm_CO = actionHelper.getText("//*[@class='account__order--paymentterm']");

    assert.ok(payTermText.includes(elePaymentTerm_CO));
    assert.equal(eleSubTotal_CO, subtotal, "Subtotal didn't match on checkout page");
    assert.equal(eleTax_CO, tax, "Tax didn't match on checkout page");
    assert.equal(eleTotal_CO, total, "Final Total didn't match on checkout page");
});

Then("Logout", () => {
    welcomePage.logout();
});

function calcTax(percentValue, totalValue) {
    if (percentValue != undefined || percentValue != 0) {
        var value = (totalValue * percentValue) / 100;
        return Math.round(value * 100) / 100;
    }
    return 0;
}

function removeCurencyString(text) {
    return text.replace("R$", "").replace(".", "").replace(",", ".").trim();
}

let productDetails = [];
When("User adds a random product to cart", () => {
    productDetails = [];
    let eleItems = "//div[@class='carousel__component--headline' and contains(.,'')]//parent::div//div[@class='owl-wrapper-outer']//div[@class='owl-item']//div[@class='carousel__item']";
    let eleBuyButton = "//div[contains(@class,'carousel__item--buy')]//button[not(contains(@class,'hidden'))]";
    let eleItemDesc = "//div[@class='carousel__item--description' or @class='carousel__item--name']";
    let eleItemId = "//div[@class='sku-details']//span[contains(@id,'ean')]";
    let eleItemUnit = "//div[@class='sku-details']//span[contains(@class,'unit')]";
    let eleItemPrice = "//div[@class='product__listing--price']//div[contains(@class,'plp__product--priceMobile')]//span[contains(@id,'productprice')]";
    let eleItemQuantity = "//span[@class='qty-val']/input";
    let elePopUpWindow = "//div[@id='cboxWrapper']//button[@id='cboxClose']";

    let productSpecs = {
        "name": "",
        "id": "",
        "price": "",
        "unit": "",
        "quantity": ""
    }
    actionHelper.pause(3);
    actionHelper.scrollIntoView("//div[contains(@class,'carouselbrandpartners')]");
    actionHelper.pause(1);
    let counter = 0;
    var eleAvailableItemButton = $$(eleItems + eleBuyButton);
    let availableProducts = 4 //eleAvailableItemButton.length;
    while (counter < availableProducts) {
        const random = Math.floor(Math.random() * availableProducts);
        var button = eleAvailableItemButton[random];
        var buttonText = button.getText().trim().toUpperCase();
        if ("COMPRAR" == buttonText) {
            var eleAvailableItemDesc = $$(eleItems + eleItemDesc);
            productSpecs.name = (actionHelper.getText(eleAvailableItemDesc[random]).trim()).toUpperCase();

            var eleAvailableItemId = $$(eleItems + eleItemId);
            productSpecs.id = actionHelper.getText(eleAvailableItemId[random]).trim();

            var eleAvailableItemUnit = $$(eleItems + eleItemUnit);
            productSpecs.unit = actionHelper.getText(eleAvailableItemUnit[random]).replace("|", "").replace(".", "").trim();

            var eleAvailableItemPrice = $$(eleItems + eleItemPrice);
            let priceText = actionHelper.getTextJs(eleAvailableItemPrice[random]);
            priceText = priceText.split("\n")[0].trim();
            productSpecs.price = priceText.replace("&nbsp;", "");

            var eleAvailableItemQty = $$(eleItems + eleItemQuantity);
            productSpecs.quantity = "";

            actionHelper.clickJs(button);
            actionHelper.pause(1);
            try {
                actionHelper.click(elePopUpWindow);
                actionHelper.pause(1);
            } catch (exception) { }
            actionHelper.waitTillPageLoad();
            productDetails[counter] = productSpecs;
            counter++;
            break;
        } // end if
    } // end while
    console.log(productDetails);
});

Then("Verify the product details in the cart", () => {
    let expectedProductSpecs = productDetails[0];
    let actualProductSpecs = {
        "name": "",
        "id": "",
        "price": "",
        "unit": "",
        "quantity": ""
    }

    let eleItemDesc = "//li[contains(@class,'item__list--item')]//span[@class='item__name']"
    let eleItemId = "//li[contains(@class,'item__list--item')]//div[@class='item__code']"
    let eleItemPrice = "//li[contains(@class,'item__list--item')]//div[@class='item__price']"
    let eleItemUnit = "//li[contains(@class,'item__list--item')]//div[@class='item__delivery']"
    let eleItemQty = "//li[contains(@class,'item__list--item')]//div[@class='cart__minusplus']//input[@name='quantity']"
    let eleCartHeadline = "//h1[@class='cart-headline']";

    actionHelper.waitForElement(eleCartHeadline);
    var ItemIds = actionHelper.getElements(eleItemId);

    for (let i = 0; i < ItemIds.length; i++) {
        actionHelper.scrollIntoView(eleCartHeadline);
        actualProductSpecs.id = (actionHelper.getText(ItemIds[i]).match(/ [0-9]*$/g) + "").trim();
        if (actualProductSpecs.id == expectedProductSpecs.id) {
            var ItemNames = actionHelper.getElements(eleItemDesc);
            actualProductSpecs.name = actionHelper.getText(ItemNames[i]);

            var ItemPrices = actionHelper.getElements(eleItemPrice);
            actualProductSpecs.price = actionHelper.getText(ItemPrices[i]);

            var ItemUnits = actionHelper.getElements(eleItemUnit);
            actualProductSpecs.unit = actionHelper.getText(ItemUnits[i]);

            var ItemQtys = actionHelper.getElements(eleItemQty);
            actualProductSpecs.quantity = actionHelper.getText(ItemQtys[i]);

            break;
        } // end if
    } // end for

    reportLog.addPlainText("Expected Product details : ");
    reportLog.addJsonObject(expectedProductSpecs);
    reportLog.addPlainText("Actual Product details : ")
    reportLog.addJsonObject(actualProductSpecs);
    assert.deepEqual(actualProductSpecs, expectedProductSpecs, "Product details doesn't match in cart");
});

Then("Delete product from the cart", () => {
    let expectedProductSpecs = productDetails[0];
    let actualProductSpecs = {
        "name": "",
        "id": "",
        "price": "",
        "unit": "",
        "quantity": ""
    }

    let eleItemId = "//li[contains(@class,'item__list--item')]//div[@class='item__code']"
    let eleDeleteIcon = "//li[contains(@class,'cartItem-desktop')]//div[@class='item__code' and contains(.,'%s')]//parent::div//parent::li//div[@class='item__menu']//button/span[not(contains(@class,'mobile'))]";
    let eleCartHeadline = "//h1[@class='cart-headline']";

    actionHelper.waitForElement(eleCartHeadline);
    var ItemIds = actionHelper.getElements(eleItemId);

    for (let i = 0; i < ItemIds.length; i++) {
        actionHelper.scrollIntoView(eleCartHeadline);
        actualProductSpecs.id = (actionHelper.getText(ItemIds[i]).match(/ [0-9]*$/g) + "").trim();
        if (actualProductSpecs.id == expectedProductSpecs.id) {
            let deleteIcon = formatString(eleDeleteIcon, actualProductSpecs.id);
            actionHelper.clickJs(actionHelper.getElement(deleteIcon));
            actionHelper.pause(2);
            actionHelper.waitTillPageLoad();
            assert.ok(!(actionHelper.isVisible(deleteIcon)), "Product not deleted: " + actualProductSpecs.id);
            break;
        } // end if
    } // end for
});

function formatString(text, value) {
    return text.replace("%s", value);
}

When("User navigate to Suggested List", () => {
    let eleSuggestedListLink = "//a[@href='/suggested-lists']";
    actionHelper.click(eleSuggestedListLink);
    actionHelper.waitTillPageLoad();
});

Then("User should see 3 sections", () => {
    let eleSuggestedBody = "//div[contains(@class,'suggested__body ')]";

    let suggestedBodyCount = actionHelper.getElements(eleSuggestedBody).length;
    assert.equal(suggestedBodyCount, 3, "No. of suggested lists is not equal 3 : " + suggestedBodyCount);
});

Then("Verify suggestions has title and subtitle", () => {
    let eleSuggestedListTitle = "//p[@class='suggested__list--title']";
    let eleSuggestedListSubTitle = "//p[@class='suggested__list--subtitle']";

    var titles = actionHelper.getElements(eleSuggestedListTitle);
    titles.forEach(x => {
        let text = x.getText();
        assert.ok(text.length > 0, "Title missing in Suggested body");
    });

    var subTitles = actionHelper.getElements(eleSuggestedListSubTitle);
    subTitles.forEach(x => {
        let text = x.getText();
        assert.ok(text.length > 0, "Sub-title missing in Suggested body");
    });
});

Then("User navigates to {string} category page", (category) => {
    let eleCategory = "//ul[@class='sub-navigation-list ']//li//a[contains(.,'" + category + "')]";

    actionHelper.clickJs(eleCategory);
    actionHelper.waitTillPageLoad();
});

Then("User adds {int} quantity product from category page", () => {
    
});

Then("Verify the free product in the cart", () => {

});