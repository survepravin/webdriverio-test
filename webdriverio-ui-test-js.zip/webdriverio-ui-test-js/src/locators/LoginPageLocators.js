class LoginPageLocators {

    constructor() {
        // this.title = "Login | Colgate Site"; 
		this.title = "Acesse e Cadastre-se! | Colgate Site";
        this.txtUsername = "#j_username";
        this.txtPassword = "#j_password";
        this.btnSubmit = "//form[@id='loginForm']//button[@type='submit']";
        this.lnkForgotPassword = "//span[contains(@class,'ahereregister')]";
        this.txtForgotPasswordDescription = "//div[@class='forgotten-password']//div[@class='description']";
    }
}

module.exports = new LoginPageLocators();