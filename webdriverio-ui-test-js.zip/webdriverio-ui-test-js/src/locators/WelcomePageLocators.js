class WelcomePageLocators {

    constructor() {
        // this.title = "Colgate Site | Homepage";
        this.title = "Colgate Site | Conheça a Loja Colgate";
        this.lnkLogin = "//div[contains(@class, 'col-sm-3 visible-sm header__search--loginregister')]//a";
        this.lblFooterText = "//div[contains(@class,'footer__container--institutional-text')]";
        this.drpProductUnits = "//div[contains(@class,'nice-select')]";
        this.listProduct = "//div[@class='carousel__item']//a";
        this.lnkMyAccount = "//div[contains(@class,'myAccountLinksHeader')]";
        this.listMyAccountLinks = "//ul[@class='nav_linksMyaccount']/li/a";
        this.lnkAddToCart = "//div[contains(@class,'desktop__nav')]//div[@class='nav-cart']//a//span[@class='nav-cart--icon']";
        this.lblProductIds = "//span[@class='sku']//following-sibling::span";
        this.lnkLogout = "//a[@href='/logout']";
        this.imgWelcomePage = "//img[@alt='Colgate']";
    }
}

module.exports = new WelcomePageLocators();