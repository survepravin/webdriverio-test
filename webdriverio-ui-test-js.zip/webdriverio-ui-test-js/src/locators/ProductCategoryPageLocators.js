class ProductCategoryPageLocators {

    constructor() {
        this.title = "Categorias | Colgate Site";
        this.listCategories = "ul.nav__links.nav__links--products.js-offcanvas-links > li[class*=nav__links--primary-has__sub] > span > a";
        this.listSubCategories = "//div[@class='sub-navigation-section']//a[contains(.,'Creme Dental')]";
        this.elementGridIcons = "//span[@class='componentlistGrid--grid-icongrid']";
        this.elementListIcons = "//span[@class='componentlistGrid--grid-iconlist']";
        this.elementSortDropDowns = "//form[@id='sortForm1']";
        this.listOfThumbnails = "//div[contains(@class,'gallery-carousel')]//div[@class='owl-wrapper-outer']//div[contains(@class,'owl-item') and not(contains(@class,'loading'))]/a/img";
        this.btnPrev = "//div[contains(@class,'gallery-carousel')]//div[contains(@class,'owl-controls')]//div[@class='owl-prev']";
        this.btnNext = "//div[contains(@class,'gallery-carousel')]//div[contains(@class,'owl-controls')]//div[@class='owl-next']";
        this.chkCheckboxes = "//div[@id='product-facet']//div[contains(@class,'facet js-facet collapseup')]//div[contains(@class,'facet__values')]//ul//li//label//span//span[@class='facet__list__mark']";
    }
}

module.exports = new ProductCategoryPageLocators();